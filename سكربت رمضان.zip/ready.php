<?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
<html dir="rtl"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title><?php echo $_POST["n"]; ?> يتمنى لك رمضان كريم قبل الجميع.</title>
<meta name="google" value="notranslate">
<meta property="og:type" content="أكتب بطاقتك الخاصة">
<meta property="og:title" content="<?php echo $_GET["n"]; ?> يتمنى لك رمضان كريم">
<meta property="og:url" content="http://ryan97.com">
<meta property="og:description" content="إضغط هنا، أكتب إسمك و انظر ما سيحدث">
<meta property="og:site_name" content="أكتب بطاقتك الخاصة">
<meta property="og:image" content="files/2018.jpg">
<link rel="stylesheet" type="text/css" href="files/new3.css">
<link rel="stylesheet" type="text/css" href="files/style4.css">
<link href="files/font.css" rel="stylesheet">
</head>
<body style="background-image: url(40007-happiestbday.jpg)">
<marquee class="m1" behavior="scroll" direction="up" scrolldelay="5"> <br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
</marquee>
<marquee class="m2" behavior="scroll" direction="up" scrolldelay="5"><br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
<img src="files/127.png" height="65px" width="34px"><br>
<img src="files/125.png" height="65px" width="18px"><br>
<img src="files/126.png" height="65px" width="34px"><br>
</marquee>
<div class="container">
<div class="main-greeting">
<div align="center html2canvas-ignore">
<div style="font-size:24px; font-weight: 800; color: white; font-family: tahoma; text-shadow:2px 2px rebeccapurple, 2px 2px rebeccapurple;">
<p id="demo" style="color:white;font-size:14px;text-shadow:1px 1px rebeccapurple, 1px 1px rebeccapurple;"></p>
<div class="main_body">
<figure>
<h1 class="naming"><?php echo $_POST["n"]; ?></h1>
<h1 class="naming"><?php echo $_POST["n"]; ?></h1>
<h1 class="naming"><?php echo $_POST["n"]; ?></h1>
<h1 class="naming"><?php echo $_POST["n"]; ?></h1>
<h1 class="naming"><?php echo $_POST["n"]; ?></h1>
</figure>
<div class="vi" style="text-align: center;">
<img src="files/Snow_falling1.gif" class="swing1" alt="diwali" style="width: 100%; height:100px;">
<img width="100%" src="files/ramadan.png">
<img class="center swing" src="files/heart.png" width="40px" height="80px" alt="Happy New Year greating wishes">
<img class="center swing1" src="files/heart2.png" width="80px" height="80px" alt="Happy New Year greating wishes">
<img class="center swing2" src="files/heart3.png" width="40px" height="80px" alt="Happy New Year greating wishes">
<img class="center swing3" src="files/heart4.png" width="40px" height="80px" alt="Happy New Year greating wishes">
<br>
<br>
<h2> <img src="files/20183.png" class="img-responsive" alt="NEW YEAR" style="width: 250px; height:150px;">
</h2>

<script>
// Set the date we're counting down to
var countDownDate = new Date("April 23, 2020 00:00:00").getTime();

// Update the count down every 01 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML ="<i>الأيام </i> " + days + " <i>، الساعات </i> " + hours + "<i>، الدقائق </i> "
  + minutes + "<i>، الثواني </i> " + seconds  ;

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "💕 رمضان مبارك 💕";
  }
}, 1000);
</script>
</div>
</div>
<p aling="center" style="font-size: 15px; color:black !important;"><b></b></p><b>أسأل الله لكم في شهر رمضان<br>
حسنات تتكاثر وذنوب تتناثر<br>
وهموم تتطاير<br>
وأن يجعل بسمتكم سعادة.<br>
وصمتكم عبادة وخاتمتكم شهادة<br>
ورزقكم في زيادة<br>
وبكل زخة مطر<br>
وبعدد من حج واعتمرأدعو الله أن يتقبل صالح العمل.<br><p></p></b><p></p> <img src="files/15.png" height="40px" width="40px">
<div class="busi"><?php echo $_POST["n"]; ?><br><img src="files/4.png" height="35px" width="35px">
</div>
</div>
</div>
</div>
<center>
<a class="mywtsp" href="https://api.whatsapp.com/send?text=*<?php echo $_POST["n"]; ?>* 🌙 أرسل لك مفاجأة 🎁 %0A1. افتح %0A2.  أكتب إسمك 
 %0A هنئ اصدقائك وعائلتك بحلول شهر رمضان المباركA 👇👇👇👇👇👇 %0A https://ryan97.com/s.php?n%3D<?php echo $_POST["n"]; ?>"><b style="font-size: 12px;"> مشاركة</b> <img width="25px" height="25px" align="left" src="files/wtsp.svg"></a>
<a class="mymsgr" href="fb-messenger://share?link=<?php echo $_POST["n"]; ?> أرسل لك مفاجاه خاصه انقر هنا 👇. ادخل اسمك https://ryan97.com/s.php?n=<?php echo $_POST["n"]; ?>" data-action="share/whatsapp/share" style="height: 43px; border-radius: 7px;     background: #448aff;">
<img align="left" width="25px" height="25px" src="files/logom.png"><b style="font-size: 12px;"> مشاركة</b></a>
<a class="myfb" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fryan97.com/s.php?n=<?php echo $_POST["n"]; ?>"  target="_blank" style="height: 43px; border-radius: 7px;">
<img align="left" width="25px" height="25px" src="files/logof.png"><b style="font-size: 12px;"> مشاركة</b></a>
</center>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106397016-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-106397016-2');
</script>
<audio autoplay="autoplay" loop="loop" hidden>
			<source src="files/ramadan.mp3" type="audio/mpeg">
		</audio></body>
</noscript>
<div style="text-align: center;"><div style="position:relative; top:0; margin-right:auto;margin-left:auto; z-index:99999">

</div></div></html>











  
  
  
